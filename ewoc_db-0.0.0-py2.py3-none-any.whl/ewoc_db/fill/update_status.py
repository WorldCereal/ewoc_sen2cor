from ewoc_db.fill.super_fill import get_connection, close_connection
import logging
import psycopg2
import sys
from datetime import datetime

MAX_DB_RETRIES = 10

# => Configures logger
logFormatter = logging.Formatter('[%(asctime)-20s] [%(name)-10s] [%(levelname)-6s] %(message)s')
consoleHandler = logging.StreamHandler(sys.stdout)
consoleHandler.setLevel(logging.DEBUG)
consoleHandler.setFormatter(logFormatter)
consoleHandler.propagate = True

logger = logging.getLogger('world-cereal')
logger.setLevel(logging.DEBUG)
logger.handlers = []
logger.addHandler(consoleHandler)
log_filename = None
s3_log_filename = None
# <= Configures logger

class S2Tile:
    def __init__(self, id, s2_tile_name, products, products_number, status=None):
        self.id = id
        self.s2_tile_name = s2_tile_name
        self.products = products
        self.products_number = products_number
        self.status = status

    @staticmethod
    def update_status(id, db_type, status="done", tif_files_number=None, logger_channel=None):
        global logger, MAX_DB_RETRIES
        if logger_channel is None:
            logger_channel = logger

        connection = get_connection(600, logger_channel)
        result = False
        nb_of_retries = 0
        while connection is not None and nb_of_retries < MAX_DB_RETRIES:
            try:
                cursor = connection.cursor()
                logger.debug("Updating status for id {} to '{}'".format(id, status))
                result_files_number = 0
                if tif_files_number is not None:
                    result_files_number = tif_files_number
                query = f"UPDATE {db_type}" \
                        " SET status='" + status + "'," + \
                        " result_files_number = " + str(result_files_number) + "," + \
                        " update_date='" + str(datetime.now()) + "'" + \
                        " WHERE id=" + str(id)

                cursor.execute(query)
                connection.commit()
                cursor.close()
                close_connection(connection, logger_channel)
                result = True
                break
            except psycopg2.OperationalError as error:
                nb_of_retries += 1
                logger_channel.error(
                    "DB operational error caught. Retrying number {} Error: {}".format(nb_of_retries, error))
                close_connection(connection)
                if nb_of_retries >= MAX_DB_RETRIES:
                    logger_channel.error(
                        "DB operational error caught. No more retries left. Error: {}".format(nb_of_retries, error))
                    break
                connection = get_connection(600, logger_channel)
                pass
            except (Exception, psycopg2.DatabaseError) as error:
                close_connection(connection, logger_channel)
                raise error
        return result


def get_next_tile(db_type, executor, status_filter="scheduled", logger_channel=None):
    """
    Get the next s1 product to process. the select is done by using FOR UPDATE in order to block
    the row from the table, creating a queue for multiple concurent processes

    Applies "processing" status to the returned tile

    :param db_type: Type of the db to select from (Choose amongst fsmac, s1_tiling, tb)
    :param executor: Name of the executor that will process the tile
    :param status_filter: [Optional, default="scheduled"] Selects tiles that follow that condition
    :param logger_channel: [Optional, default=None] Specify a logger if needed
    :return: the s2_tile, and the boolean db_error
    """
    global logger, MAX_DB_RETRIES

    if logger_channel is None:
        logger_channel = logger
    s2_tile = None
    db_error = False
    nb_of_retries = 0
    connection = get_connection(600, logger_channel)

    if status_filter != "NULL":
        status_filter = f" = '{status_filter}'"
    else:
        status_filter = " is NULL"

    while connection is not None and nb_of_retries < MAX_DB_RETRIES:
        try:
            # first, check if a previous run for this branch took place.
            # if the node was previously killed before ending the job, re-use the job
            query = f"SELECT * FROM {db_type} " + \
                    "WHERE status = 'processing' and executor = '" + executor + "'"
            logger_channel.info("Checking if the node was previously killed without finishing its job")
            logger_channel.debug("query = {}".format(query))
            cursor = connection.cursor()
            cursor.execute(query)
            rows = cursor.fetchall()
            if len(rows) == 0:
                logger_channel.info(
                    "The executor {} does not have a previous unfinished job. Checking if there are more tiles to process...".format(
                        executor))
                if db_type == "s1_tiling":
                    query = f"SELECT * FROM {db_type} " + \
                            f"WHERE status {status_filter} " + \
                            f"ORDER BY s1_products_number DESC FOR UPDATE OF {db_type} SKIP LOCKED LIMIT 1"
                else:
                    query = f"SELECT * FROM {db_type} " + \
                            f"WHERE status {status_filter} " + \
                            f"ORDER BY products_number DESC FOR UPDATE OF {db_type} SKIP LOCKED LIMIT 1"
                cursor = connection.cursor()
                cursor.execute(query)
                rows = cursor.fetchall()
            else:
                logger_channel.info("The node was killed before finishing its job. Reloading work.")
            logger_channel.debug("Nb of rows = {}".format(len(rows)))
            if len(rows) == 1:
                logger_channel.debug("DB = {}".format(rows[0]))
                s2_tile = S2Tile(int(rows[0][0]), rows[0][1], rows[0][2], rows[0][3])
                logger_channel.debug("Getting frame to process: tile = {} | tile = {}".format(s2_tile.s2_tile_name,
                                                                                      s2_tile.products))
                cursor_upd = connection.cursor()
                logger_channel.debug("Updating status for id {} to 'processing'".format(s2_tile.id))
                query = f"UPDATE {db_type} " \
                        "SET status='processing', " + \
                        "result_files_number = 0, " + \
                        "update_date='" + str(datetime.now()) + "', " + \
                        "executor='" + str(executor) + "' " + \
                        "WHERE id=" + str(s2_tile.id)
                cursor_upd.execute(query)
                connection.commit()
                cursor_upd.close()
            else:
                logger_channel.info(f"No more tiles to get from database {db_type}")
            # Close the cursor and connection
            cursor.close()
            close_connection(connection, logger_channel)
            break
        except psycopg2.OperationalError as error:
            nb_of_retries += 1
            logger_channel.error("DB operational error caught. Retrying number {} Error: {}".format(nb_of_retries, error))
            close_connection(connection, logger_channel)
            s2_tile = None
            if nb_of_retries >= MAX_DB_RETRIES:
                logger_channel.error(
                    "DB operational error caught. No more retries left. Error: {}".format(nb_of_retries, error))
                db_error = True
                break
            connection = get_connection(600, logger_channel)
            pass
        except (Exception, psycopg2.DatabaseError) as error:
            close_connection(connection, logger_channel)
            raise error
    return s2_tile, db_error
