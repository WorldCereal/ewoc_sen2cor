import json
import logging
import os
import psycopg2
import sys
import time
 
from datetime import datetime
from random import randrange


def setup(db_type):
    # S1_PRODUCT_BUCKET_NAME = "world-cereal"
    global logger
    # => Defines folders
    base_folder = "/"
    s1_preprocess_task_scheduler_folder = base_folder + os.environ["TMP_FOLDER"] + "db_fill_task/"
    log_folder = s1_preprocess_task_scheduler_folder + "logs/"
    os.makedirs(log_folder, exist_ok=True)
    # <= Defines folders

    # => Configures logger
    logFormatter = logging.Formatter('[%(asctime)-20s] [%(name)-10s] [%(levelname)-6s] %(message)s')
    consoleHandler = logging.StreamHandler(sys.stdout)
    consoleHandler.setLevel(logging.DEBUG)
    consoleHandler.setFormatter(logFormatter)
    consoleHandler.propagate = True
    log_file_name = log_folder + f"fill_db_{db_type}_" + time.strftime("%Y%m%d_%H%M%S") + ".log"
    fileHandler = logging.FileHandler(log_file_name)
    fileHandler.setFormatter(logFormatter)
    logger = logging.getLogger('fill-db')
    logger.setLevel(logging.DEBUG)
    logger.handlers = []
    logger.addHandler(consoleHandler)
    logger.addHandler(fileHandler)
    # <= Configures logger
    return logger


def get_connection(connection_timeout=1, logger_channel=None):
    # the connection_timeout is in seconds and has to be a positive integer.
    # more than 10 minutes is a bottleneck
    global logger
    if logger_channel is None:
        logger_channel = logger
    
    #warning_msg_displayed = False
    if connection_timeout < 0 or connection_timeout > 600 :
        connection_timeout_ms = 1000
    else:
        connection_timeout_ms = connection_timeout * 1000
    logger_channel.debug("Trying to connect to database, maximum allowed time to connect is {} ms ".format(connection_timeout_ms))
    timeout_counter = 0
    display_err_msg_timeout_counter = 0
    while timeout_counter <= connection_timeout_ms: 
        try:
            start = time.time()
            postgres_connect_timeout = 10 
            if postgres_connect_timeout > connection_timeout:
                postgres_connect_timeout = connection_timeout
            time_to_stay = (connection_timeout_ms - timeout_counter) / 1000
            if postgres_connect_timeout > time_to_stay:
                postgres_connect_timeout = time_to_stay
            connection = psycopg2.connect(
                    host=os.environ["POSTGRESQL_HOST"],
                    port=os.environ["POSTGRESQL_PORT"],
                    database=os.environ["POSTGRESQL_DATABASE"],
                    user=os.environ["POSTGRESQL_USER"],
                    password=os.environ["POSTGRESQL_PASSWORD"],
                    connect_timeout=postgres_connect_timeout
                )
            #if warning_msg_displayed is True:
            logger_channel.debug("Connection to database succeeded in {} seconds ({} | {})".format((timeout_counter / 1000) + (time.time() - start), (timeout_counter / 1000),  (time.time() - start)))
            return connection
        except psycopg2.OperationalError as error:
            logger_channel.error("Operational error caught. Retrying connection. Error: {}".format(error))
            pass
        except (Exception, psycopg2.Error) as error:
            logger_channel.error("Other exception than operational error caught: {}".format(error))
            # logger.error("Other exception than operational error caught: {}".format(error))
            raise(error)
        time_spent_in_connection_ms = (time.time() - start) * 1000
        if(time_spent_in_connection_ms > 8000):
            logger_channel.debug("Time spent in psycopg2.connect function: {}".format(time_spent_in_connection_ms))
        # retrying
        sleeping_time_ms = randrange(100, 2000, 1)
        time.sleep(sleeping_time_ms / 1000)            
        timeout_counter += (sleeping_time_ms + time_spent_in_connection_ms)
        if(timeout_counter - display_err_msg_timeout_counter > 20000 or display_err_msg_timeout_counter == 0):
            display_err_msg_timeout_counter = timeout_counter
            #warning_msg_displayed = True
            logger_channel.error("Cannot connect to database. Retrying for {} more seconds".format((connection_timeout_ms - timeout_counter) / 1000))
    debug_string = "Timeout for connecting to database reached! Couldn't get the connection database handler. The process will exit"
    logger_channel.error(debug_string)
    # for better debugging, write in the main file also 
    logger.error(debug_string)
    return None


def close_connection(connection, logger_channel=None):
    global logger
    if logger_channel is None:
        logger_channel = logger
    logger_channel.debug("Closing database connection function")
    if connection is not None:
        connection.close()
        logger_channel.debug("Database connection closed")
    logger_channel.debug("Exit from closing the database connection function")


def fill_db(db_type, query_a, query_b, filename, nb_of_products):
    
    # use the input json file to get the data to insert
    connection = get_connection(20)
    if connection is None:
        logger.error("Could not get the database handler. Exit...")
        sys.exit(-1) 

    with open(filename, 'r') as filehandle:
        s2_tiles = json.load(filehandle)
    '''
    s2_tile_names = []
    for s2_tile in s2_tiles.items():
        s2_tile_names.append(s2_tile[0])
    logger.debug("{}".format(s2_tile_names))
    sys.exit(0)
    '''
    try:
        cursor = connection.cursor()
        total_inserted = 0
        records_nb = 0
        logger.debug("Number of s2 tiles found in json file = {}".format(len(s2_tiles)))
        for s2_tile in s2_tiles:
            #logger.debug("s2_tile = {}".format(s2_tile))

            if db_type == "fsmac":
                products_from_json = [s2_tiles["{}".format(s2_tile)]["S2_PROC"]["INPUTS"] +
                                      s2_tiles["{}".format(s2_tile)]["L8_PROC"]["INPUTS"]]
            elif db_type == "s1_tiling":
                products_from_json = s2_tiles["{}".format(s2_tile)]["SAR_PROC"]["INPUTS"]

            elif db_type == "thermal_bands":
                products_from_json = s2_tiles["{}".format(s2_tile)]["L8_TIRS"]

            for group_of_products in products_from_json:
                products_string = ""
                products_counter = 0
                products_failed_number = 0
                for product in group_of_products:
                    products_string = products_string + product + ","
                    products_counter += 1

                    if products_counter % int(nb_of_products) == 0 or products_counter == len(group_of_products):
                        # remove the last comma
                        products_string = products_string[:-1]
                        products_number = len(products_string.split(","))
                        s2_tile_query_string = query_a.format(s2_tile, products_string, products_number)
                        query = query_b + s2_tile_query_string

                        try:
                            cursor.execute(query)
                            logger.info("Database commit for {} s2 tiles".format(total_inserted))
                            connection.commit()
                        except (Exception, psycopg2.Error) as error:
                            logger.error("Got exception when trying to insert record for: {} Database exception: {}".format(s2_tile_query_string, error))
                            # reset the counters
                            products_string = ""

                            products_failed_number += products_number
                            continue
                        records_nb += 1
                        # reset the counters
                        logger.debug("Inserted {} products from a total of {}".format(products_counter - products_failed_number, len(products_from_json)))
                        products_string = ""
                if products_counter - products_failed_number > 0:
                    # information regarding the number of inserted products
                    total_inserted += 1
            else:
                if db_type == "fsmac":
                    logger.error("{} tile: nothing has been found to insert into database. Check the [S2_PROC -> INPUTS] and [L8_PROC -> INPUTS] sections for this tile inside the {} file".format(s2_tile, filename))
                elif db_type == "s1_tiling":
                    logger.error("{} tile: not all products have been inserted. Either duplicated or check the [SAR_PROC -> INPUTS] section for this tile inside the {} file".format(s2_tile, filename))
                elif db_type == "thermal_bands":
                    logger.error("{} tile: nothing has been found to insert into database. Check the L8_TIRS section for this tile inside the {} file".format(s2_tile, filename))

            if total_inserted % 50000 == 0 and total_inserted != 0:
                logger.info("S2 tiles inserted: {}".format(total_inserted))
        logger.info("A total of {} s2 tiles have been inserted ({} records)".format(total_inserted, records_nb))
        cursor.close()

    except (Exception, psycopg2.Error) as error:
        logger.error("Database exception: {}".format(error))
        if connection is not None:
            logger.error("CLOSING DB CONNECTION")
            close_connection(connection)
        logger.error("RAISING ERROR")
        raise(error)
    close_connection(connection)
    
def main(db_type, query_a, query_b, filename, nb_of_products):

    script_start = datetime.now()
    setup(db_type)

    global logger
    logger.info("=> Enter script...")
    #print(os.environ["POSTGRESQL_HOST"])
    #print(os.environ["POSTGRESQL_PORT"])
    #print(os.environ["POSTGRESQL_DATABASE"])
    #print(os.environ["POSTGRESQL_USER"])
    #print(os.environ["POSTGRESQL_PASSWORD"])
    try:
        fill_db(db_type, query_a, query_b, filename, nb_of_products)
    except Exception as e:
        logger.info("Exception: {}".format(e))
        
    logger.info("<= Exit script : " + str(datetime.now() - script_start))
    
if __name__ == '__main__':
    main()

