=======
ewoc_db
=======


Manage the processing WorldCereal database 


Description
===========

This python package provides the code to:
- create the EWoC database
- fill the database from a workplan
- manage the database (clean, ...)
- query products into the database


.. _pyscaffold-notes:

Note
====

This project has been set up using PyScaffold 4.0.2. For details and usage
information on PyScaffold see https://pyscaffold.org/.
